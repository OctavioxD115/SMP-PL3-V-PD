        position.xy += vec2(YAXIS * sin(frameTimeCounter * FRAMETIME1), XAXIS * cos(frameTimeCounter * FRAMETIME2));

        gl_Position = gl_ProjectionMatrix * gbufferModelView * position;