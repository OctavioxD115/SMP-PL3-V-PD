#if COLOR_PRESET == 0
#include "/lib/color/data/data1.glsl"
#elif COLOR_PRESET == 1
#include "/lib/color/data/data2.glsl"
#elif COLOR_PRESET == 2
#include "/lib/color/data/data3.glsl"
#elif COLOR_PRESET == 3
#include "/lib/color/data/data4.glsl"
#endif
const ivec4 ToD[25] = ivec4[25](ivec4(0,R,G,B), //hour,r,g,b
								ivec4(1,RI,GI,BI),
								ivec4(2,RII,GII,BII),
								ivec4(3,RIII,GIII,BIII),
								ivec4(4,RIV,GIV,BIV),
								ivec4(5,RV,GV,BV),
								ivec4(6,RVI,GVI,BVI),
								ivec4(7,RVII,GVII,BVII),
								ivec4(8,RVIII,GVIII,BVIII),
								ivec4(9,RIX,GIX,BIX),
								ivec4(10,RX,GX,BX),
								ivec4(11,RXI,GXI,BXI),
								ivec4(12,RXII,GXII,BXII),
								ivec4(13,RXIII,GXIII,BXIII),
								ivec4(14,RXIV,GXIV,BXIV),
								ivec4(15,RXV,GXV,BXV),
								ivec4(16,RXVI,GXVI,BXVI),
								ivec4(17,RXVII,GXVII,BXVII),
								ivec4(18,RXVIII,GXVIII,BXVIII),
								ivec4(19,RXIX,GXIX,BXIX),
								ivec4(20,RXX,GXX,BXX),
								ivec4(21,RXXI,GXXI,BXXI),
								ivec4(22,RXXII,GXXII,BXXII),
								ivec4(23,RXXIII,GXXIII,BXXIII),
								ivec4(24,RXXIV,GXXIV,BXXIV));
										
vec3 sky_color = ivec3(60,170,255)/255.0;