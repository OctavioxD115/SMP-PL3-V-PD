# **Terms of use**

###### 

###### **You can:**

* ✅ Use it in mod packs
* ✅ Use it for Content Creation like YouTube videos (Linking back to this or the other available pages (Modrinth, Planetminecraft, CurseForge))



###### **You cannot:**

* ❌ Redistribute edited or unedited assets
* ❌ Re-upload the pack
* ❌ Claim ownership over our assets



These terms may be changed as we deem necessary and at any time.

Versions of this pack before 1.9.2 make use of NegativeSpaces4 resource pack by AmberW/AmberWat which is under Creative Commons Attribution 4.0 International terms.

###### 

###### **Credits:**

* mr\_ch0c0late (Creator and Idea)
* Zartrix (PackDev)
* Moggla (Creator of MC Language Formatter)
* KikuGie (Creator of our Edited RespackOpts config)

##### 

###### **Versions pre 1.9.2:**

* AmberW/AmberWat (Creator of NegativeSpaces4)



###### **Former Translation Contributions:**

* Leroidesafk (French, Romanian, Portuguese(BR), Italian)
* Agente\_511 (Portuguese(PT))
* Magnogen (English(GB))
* Blazemetal\_VN (Vietnamese)
* Victorth (Finding and fixing bugs in Portuguese(BR))

