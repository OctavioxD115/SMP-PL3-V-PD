#version 130

/*

// !! DO NOT REMOVE !! !! DO NOT REMOVE !!

// This code is from Chocapic13' shaders
// Read the terms of modification and sharing before changing something below please !

// !! DO NOT REMOVE !! !! DO NOT REMOVE !!

//------------------------------------
//RedHat - Based on Chocapic13' and CYBOX
//
//If you have questions, suggestions or bugs you want to report, please contanct me on curseforge
//
//
//Before editing, please read the LICENSE
//Thanks
//------------------------------------
*/

varying vec4 texcoord;

uniform sampler2D tex;

//////////////////////////////VOID MAIN//////////////////////////////
//////////////////////////////VOID MAIN//////////////////////////////
//////////////////////////////VOID MAIN//////////////////////////////
//////////////////////////////VOID MAIN//////////////////////////////
//////////////////////////////VOID MAIN//////////////////////////////

void main() {
	gl_FragData[0] = texture2D(tex,texcoord.xy);
}