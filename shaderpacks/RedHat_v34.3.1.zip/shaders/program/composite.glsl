
///// FRAGMENT SHADER //////////////////////////////////////////////////////////////////////////////////////////////
#ifdef FSH

const int RGBA16 = 0;
const int gdepthFormat = RGBA16;

varying vec4 texcoord;
varying vec4 lightS;

varying vec3 lightVector;
varying vec3 sunVec;
varying vec3 moonVec;
varying vec3 upVec;
varying vec3 sunlight;
varying vec3 moonlight;
varying vec3 ambient_color;
varying vec2 pos;

varying float handItemLight;
varying float eyeAdapt;
varying float SdotU;
varying float MdotU;
varying float sunVisibility;
varying float moonVisibility;
varying float isBlack;

uniform sampler2D gcolor;
uniform sampler2D depthtex0;
uniform sampler2D depthtex1;
uniform sampler2D gnormal;
uniform sampler2DShadow shadow;
uniform sampler2D shadowtex1;
uniform sampler2D gaux1;
uniform sampler2D noisetex;
uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferModelView;
uniform mat4 shadowProjection;
uniform mat4 shadowModelView;
uniform vec3 sunPosition;
uniform vec3 moonPosition;
uniform vec3 upPosition;
uniform vec3 cameraPosition;
uniform float near;
uniform float far;
uniform float viewWidth;
uniform float viewHeight;
uniform float rainStrength;
uniform float wetness;
uniform float centerDepthSmooth;
uniform float aspectRatio;
uniform float frameTimeCounter;
uniform ivec2 eyeBrightness;
uniform ivec2 eyeBrightnessSmooth;
uniform int isEyeInWater;
uniform int worldTime;
uniform int fogMode;

#include "/lib/timecalculation.glsl"

float cdist(vec2 coord){
    return distance(coord,vec2(0.5))*2.0;
}

vec3 convertScreenSpaceToWorldSpace(vec2 co, float depth) {
    vec4 fragposition = gbufferProjectionInverse * vec4(vec3(co, depth) * 2.0 - 1.0, 1.0);
    fragposition /= fragposition.w;
    return fragposition.xyz;
}

vec3 convertCameraSpaceToScreenSpace(vec3 cameraSpace) {
    vec4 clipSpace = gbufferProjection * vec4(cameraSpace, 1.0);
    vec3 NDCSpace = clipSpace.xyz / clipSpace.w;
    vec3 screenSpace = 0.5 * NDCSpace + 0.5;
    return screenSpace;
}

vec3 nvec3(vec4 pos) {
    return pos.xyz/pos.w;
}

vec4 nvec4(vec3 pos) {
    return vec4(pos.xyz, 1.0);
}

float edepth(vec2 coord) {
	return texture2D(depthtex0,coord).z;
}

float ld(float depth) {
    return (2.0 * near) / (far + near - depth * (far - near));
}

vec2 newtc = texcoord.xy;
vec3 sky_color = normalize(vec3(0.1, 0.35, 1.0));

vec2 texel = vec2(1.0/viewWidth,1.0/viewHeight);

float pw = 1.0/ viewWidth;
float ph = 1.0/ viewHeight;

vec3 aux = texture2D(gaux1, texcoord.st).rgb;
vec3 normal = texture2D(gnormal, texcoord.st).rgb * 2.0f - 1.0f;

vec3 fragpos = vec3(texcoord.st, texture2D(depthtex0, texcoord.st).r);
float pixeldepth = texture2D(depthtex0,texcoord.xy).x;

// Lightmap //

float handlight = handItemLight;
float lightmap = pow(aux.r,3.0);
float light_jitter = 1.0-sin(frameTimeCounter*1.4*TORCH_LIGHT_JITTER_SPEED+cos(frameTimeCounter*1.9*TORCH_LIGHT_JITTER_SPEED))*0.05;
float torch_lightmap = pow(aux.b*light_jitter,TORCH_ATTEN);
float sky_lightmap = pow(max(aux.r-1.5/16.,0.0)*(1/(1-1.5/16.)),ATTENUATION);

// Wetness //

float iswet = wetness*pow(sky_lightmap,5.0)*sqrt(0.5+max(dot(normal,upVec),0.0));

const vec2 shadow_offsets[60] = vec2[60]( vec2( 0.0000, 0.2500 ),
								vec2	( -0.2165, 0.1250 ),
								vec2	( -0.2165, -0.1250 ),
								vec2	( -0.0000, -0.2500 ),
								vec2	( 0.2165, -0.1250 ),
								vec2	( 0.2165, 0.1250 ),
								vec2	( 0.0000, 0.5000 ),
								vec2	( -0.2500, 0.4330 ),
								vec2	( -0.4330, 0.2500 ),
								vec2	( -0.5000, 0.0000 ),
								vec2	( -0.4330, -0.2500 ),
								vec2	( -0.2500, -0.4330 ),
								vec2	( -0.0000, -0.5000 ),
								vec2	( 0.2500, -0.4330 ),
								vec2	( 0.4330, -0.2500 ),
								vec2	( 0.5000, -0.0000 ),
								vec2	( 0.4330, 0.2500 ),
								vec2	( 0.2500, 0.4330 ),
								vec2	( 0.0000, 0.7500 ),
								vec2	( -0.2565, 0.7048 ),
								vec2	( -0.4821, 0.5745 ),
								vec2	( -0.6495, 0.3750 ),
								vec2	( -0.7386, 0.1302 ),
								vec2	( -0.7386, -0.1302 ),
								vec2	( -0.6495, -0.3750 ),
								vec2	( -0.4821, -0.5745 ),
								vec2	( -0.2565, -0.7048 ),
								vec2	( -0.0000, -0.7500 ),
								vec2	( 0.2565, -0.7048 ),
								vec2	( 0.4821, -0.5745 ),
								vec2	( 0.6495, -0.3750 ),
								vec2	( 0.7386, -0.1302 ),
								vec2	( 0.7386, 0.1302 ),
								vec2	( 0.6495, 0.3750 ),
								vec2	( 0.4821, 0.5745 ),
								vec2	( 0.2565, 0.7048 ),
								vec2	( 0.0000, 1.0000 ),
								vec2	( -0.2588, 0.9659 ),
								vec2	( -0.5000, 0.8660 ),
								vec2	( -0.7071, 0.7071 ),
								vec2	( -0.8660, 0.5000 ),
								vec2	( -0.9659, 0.2588 ),
								vec2	( -1.0000, 0.0000 ),
								vec2	( -0.9659, -0.2588 ),
								vec2	( -0.8660, -0.5000 ),
								vec2	( -0.7071, -0.7071 ),
								vec2	( -0.5000, -0.8660 ),
								vec2	( -0.2588, -0.9659 ),
								vec2	( -0.0000, -1.0000 ),
								vec2	( 0.2588, -0.9659 ),
								vec2	( 0.5000, -0.8660 ),
								vec2	( 0.7071, -0.7071 ),
								vec2	( 0.8660, -0.5000 ),
								vec2	( 0.9659, -0.2588 ),
								vec2	( 1.0000, -0.0000 ),
								vec2	( 0.9659, 0.2588 ),
								vec2	( 0.8660, 0.5000 ),
								vec2	( 0.7071, 0.7071 ),
								vec2	( 0.5000, 0.8660 ),
								vec2	( 0.2588, 0.9659 ));

float ctorspec(vec3 ppos, vec3 lvector, vec3 normal,float rough,float fpow) {

	vec3 pos = -normalize(ppos);
	vec3 cHalf = normalize(lvector + pos);

	float normalDotHalf = dot(normal, cHalf);
	float normalDotHalf2 = normalDotHalf * normalDotHalf;

	float roughness2 = rough;
	float exponent = -(1.0 - normalDotHalf2) / (normalDotHalf2 * roughness2);
	float e = 2.71828182846;
	float D = pow(e, exponent) / (roughness2 * normalDotHalf2 * normalDotHalf2);

	float normalDotEye = dot(normal, pos);
	float F = pow(1.0 - normalDotEye, fpow);

	float normalDotLight = dot(normal, lvector);
	float X = 2.0 * normalDotHalf / dot(pos, cHalf);
	float G = min(1.0, min(X * normalDotLight, X * normalDotEye));
	float pi = 3.1415927;
	float CookTorrance = (D*G)/acos(normalDotEye);

	return clamp(CookTorrance/pi,0.0,1.0);
}

float Blinn_Phong(vec3 ppos, vec3 lvector, vec3 normal,float fpow, float gloss, float visibility)  {
	vec3 lightDir = vec3(lvector);

	vec3 surfaceNormal = normal;
	float cosAngIncidence = dot(surfaceNormal, lightDir);
	cosAngIncidence = clamp(cosAngIncidence, 0.0, 1.0);

	vec3 viewDirection = normalize(-ppos);

	vec3 halfAngle = normalize(lightDir + viewDirection);
	float blinnTerm = dot(surfaceNormal, halfAngle);

	float normalDotEye = dot(normal, normalize(ppos));
	float fresnel = clamp(pow(1.0 + normalDotEye, 5.0),0.0,1.0);
	fresnel = fresnel*0.85 + 0.15 * (1.0-fresnel);
	float pi = 3.1415927;
	float n =  pow(2.0,gloss*8.0+log(1+length(ppos)/2.));
	return (pow(blinnTerm, n )*((n+8.0)/(8*pi)))*visibility;
}

float getnoise(vec2 pos) {
	return abs(fract(sin(dot(pos ,vec2(18.9898f,28.633f))) * 4378.5453f));
}

float fx(float x) {
return (2 *(-sin(x)*sin(x)*sin(x) + 3*sin(x) + 3*x)) / 3;

}
float fx2(float x) {
return (-cos(x) * sin(x) + 6*x) / 2;

}

vec3 skyLightColor (vec3 fposition) {
vec3 skycoaa = ivec3(60,170,255)/255.0;
vec3 sky_color = pow(skycoaa,vec3(2.2));
vec3 nsunlight = normalize(pow(sunlight,vec3(2.2)));
sky_color = normalize(mix(sky_color,vec3(0.25,0.3,0.4)*length(ambient_color),rainStrength)); //normalize colors in order to don't change luminance
vec3 sVector = normalize(fposition);
const float PI = 3.14159265359;
float cosT = dot(sVector,upVec);
float T = acos(cosT);
float absCosT = abs(cosT);
float cosS = SdotU;
float S = acos(cosS);
float cosY = dot(sunVec,sVector);
float Y = acos(cosY);

float tL = ((fx(Y+PI/2.0)-fx(Y-PI/2.0))*2.5 + fx2(T+PI/2.0)-fx2(T-PI/2.0))/6.28;

float McosS = MdotU;
float MS = acos(McosS);
float McosY = dot(moonVec,sVector);
float MY = acos(McosY);
float tLMoon = ((fx(MY+PI/2.0)-fx(MY-PI/2.0))*3.0 + fx2(T+PI/2.0)-fx2(T-PI/2.0))/6.28;

return mix(sky_color, nsunlight,1-exp(-0.16*tL*(1-rainStrength*0.8)))*tL*sunVisibility*(1-rainStrength*0.8) + tLMoon*moonVisibility*moonlight;
}

float subSurfaceScattering(vec3 pos, float N) {

return pow(max(dot(lightVector,normalize(pos)),0.0),N)*(N+1)/6.28;

}

vec3 getSkyColor(vec3 fposition) {

// Sky Gradient //

vec3 skycoaa = ivec3(30,170,255)/255.0;
vec3 sky_color = pow(skycoaa,vec3(2.2));
vec3 nsunlight = normalize(pow(sunlight,vec3(2.2)));
vec3 sVector = normalize(fposition);

sky_color = normalize(mix(sky_color,vec3(0.25,0.3,0.4)*length(ambient_color),rainStrength)); //normalize colors in order to don't change luminance

float Lz = 1.0;
float cosT = dot(sVector,upVec); //T=S-Y
float absCosT = abs(cosT);
float cosS = SdotU;
float S = acos(cosS);				//S=Y+T	-> cos(Y+T)=cos(S) -> cos(Y)*cos(T) - sin(Y)*sin(T) = cos(S)
float cosY = dot(sunVec,sVector);
float Y = acos(cosY);				//Y=S-T

float a = -0.7;
float b = -0.2;
float c = 12.0;
float d = -0.9;
float e = 3.0;

// Day Sky //

float L =  (1+a*exp(b/(absCosT+0.01)))*(1+c*exp(d*Y)+e*cosY*cosY);
L = pow(L,1.0-rainStrength*0.8)*(1.0-rainStrength*0.2); //modulate intensity when raining
vec3 skyColorSun = mix(sky_color, nsunlight,1-exp(-0.13*L*(1-rainStrength*0.8)))*L ; //affect color based on luminance (0% physically accurate)
skyColorSun *= sunVisibility;

// Night Sky //

float McosS = MdotU;
float MS = acos(McosS);
float McosY = dot(moonVec,sVector);
float MY = acos(McosY);

float L2 =  (1+a*exp(b/(absCosT+0.01)))*(1+c*exp(d*MY)+e*McosY*McosY);
L2 = pow(L2,1.0-rainStrength*0.8)*(1.0-rainStrength*0.2); //modulate intensity when raining
vec3 skyColormoon = mix(moonlight,normalize(vec3(0.25,0.3,0.4))*length(moonlight),rainStrength)*L2*0.4 ; //affect color based on luminance (0% physically accurate)
skyColormoon *= moonVisibility;

sky_color = skyColormoon+skyColorSun/2.0;

return sky_color;
}

float PosDot(vec3 v1,vec3 v2) {
return max(dot(v1,v2),0.0);
}

float waterH(vec3 posxz) {

float wave = 0.0;
float factor = 1.0;
float amplitude = 0.8;
float speed = 8.0;
float size = 1.6;

float px = posxz.x/50.0 + 250.0;
float py = posxz.z/50.0  + 250.0;

float fpx = abs(fract(px*20.0)-0.5)*2.0;
float fpy = abs(fract(py*20.0)-0.5)*2.0;

float d = length(vec2(fpx,fpy));

for (int i = 1; i < 4; i++) {
wave -= d*factor*cos( (1/factor)*px*py*size + 1.0*frameTimeCounter*speed);
factor /= 2;
}

factor = 1.0;
px = -posxz.x/50.0 + 250.0;
py = -posxz.z/150.0 - 250.0;

fpx = abs(fract(px*20.0)-0.5)*2.0;
fpy = abs(fract(py*20.0)-0.5)*2.0;

d = length(vec2(fpx,fpy));
float wave2 = 0.0;
for (int i = 1; i < 3; i++) {
wave2 -= d*factor*cos( (1/factor)*px*py*size + 1.0*frameTimeCounter*speed);
factor /= 2;
}

return amplitude*wave2+amplitude*wave;
}

float noisetexture(vec2 coord, float offset, float speed){
return texture2D(noisetex, coord*offset + frameTimeCounter*speed).x/offset;
}

float waterH(vec2 posxz) {
	
posxz = posxz * vec2(0.0,0.0);

vec2 coord = fract(posxz / 1000);

float noise = noisetexture(coord, 0.5, 0.00130);
noise -= noisetexture(coord, 0.5, -0.00130);
noise += noisetexture(coord, 2.0, 0.00145);
noise -= noisetexture(coord, 2.0, -0.00145);
noise += noisetexture(coord, 3.5, 0.00160);
noise -= noisetexture(coord, 3.5, -0.00160);
noise += noisetexture(coord, 5.0, 0.00175);
noise -= noisetexture(coord, 5.0, -0.00175);

return noise;
}

#ifdef WATER_CAUSTIC
vec3 waterCaustic(vec3 fposition,vec3 color) {
vec3 underwaterpos = vec3(texcoord.st, texture2D(depthtex1, texcoord.st).r);
underwaterpos = nvec3(gbufferProjectionInverse * nvec4(underwaterpos * 2.0 - 1.0));
vec4 worldpositionuw = gbufferModelViewInverse * vec4(underwaterpos,1.0);
vec3 wpos = (worldpositionuw.xyz+cameraPosition.xyz);

#if CAUSTIC_STYLE == 0
#include "/lib/effect/water/causticnoise/noise1.glsl"
#elif CAUSTIC_STYLE == 1
#include "/lib/effect/water/causticnoise/noise2.glsl"
#elif CAUSTIC_STYLE == 2
#include "/lib/effect/water/causticnoise/noise3.glsl"
#endif

float causticstrength = max((noise-1.2),0.0);
float wca = (0.1/CAUSTIC_STRENGTH);
float caustic = (1.0 - (pow(wca,causticstrength)));

vec3 causticColorSunrise = vec3(30,20,10)/255.0;
vec3 causticColorNoon = vec3(20,20,20)/255.0;
vec3 causticColorSunset = vec3(30,20,10)/255.0;
vec3 causticColorNight = vec3(0,0,0)/255.0;
vec3 caustic_color = vec3((causticColorSunrise+TimeSunrise)+(causticColorNoon+TimeNoon)+(causticColorSunset+TimeSunset)+(causticColorNight/50.0+TimeMidnight))/255.0;
vec3 wc = mix(color,caustic_color,caustic);
return wc;
}
#endif

vec3 watercolor = vec3(RED,GREEN,BLUE); //water color and opacity (r,g,b,opacity)

#ifdef VOLUMETRIC_LIGHT

// derived from: http://devlog-martinsh.blogspot.nl/2011/03/glsl-8x8-bayer-matrix-dithering.html
float find_closest(vec2 pos, float samplev)
{
		float dither[64] = float[64](
		0, 32, 8, 40, 2, 34, 10, 42, 			/* 8x8 Bayer ordered dithering 	*/
		48, 16, 56, 24, 50, 18, 58, 26,			/* pattern. Each input pixel 	*/
		12, 44, 4, 36, 14, 46, 6, 38, 			/* is scaled to the 0..63 range */
		60, 28, 52, 20, 62, 30, 54, 22,			/* before looking in this table */
		3, 35, 11, 43, 1, 33, 9, 41, 			/* to determine the action. 	*/
		51, 19, 59, 27, 49, 17, 57, 25,
		15, 47, 7, 39, 13, 45, 5, 37,
		63, 31, 55, 23, 61, 29, 53, 21);

	vec2 texMod = pos;
	vec2 aspectCorrect = vec2(viewWidth, viewHeight);
	texMod = mod(texMod * aspectCorrect, sqrt(64));
	float limit;

	for (int i = 0; i < (int(texMod.x) + int(texMod.y)*sqrt(64)); i++) {
		limit = (dither[i])/sqrt(64 * 64);
	}
	return limit * samplev;
}

float getDepth(float depth) {
    return 2.0 * near * far / (far + near - (2.0 * depth - 1.0) * (far - near));
}

float distx(float dist){
	return (((dist - near) * far) / ((far - near) * dist));
}

float dynamicExposure()
{
	return mix(1.0,0.0,(pow(eyeBrightnessSmooth.y / 480.0f, 5.0f)));
}

struct vlStruct {

	vec4 fragpos;
	vec4 worldposition;

	vec3 pos;

	vec2 pushback;

	float Quality;
	float steps;
	float ditherPattern;
	float maxDist;
	float minDist;
	float d;
	float distb;
	float distortFactor;
	float VolumetricRays;
	float weight;

} vl;

float GetVolumetricRays() {

	///////////////////////Setting up functions///////////////////////

		vl.Quality = 4.0 / VL_QUALITY;
		vl.steps = vl.Quality;

		vl.ditherPattern = find_closest(texcoord.st, vl.steps);

		vl.maxDist = (180.0);
		vl.minDist = (0.01);

		vl.minDist += vl.ditherPattern;
		vl.weight = (vl.maxDist / vl.steps);

		vl.pushback = vec2(0.001, -0.001);										//Fixes light leakage from walls

		for (vl.minDist; vl.minDist < vl.maxDist;) {

		///////////////////////MAKING VL NOT GO THROUGH WALLS///////////////////////

			if (getDepth(pixeldepth) < vl.minDist){
				break;
			}

		///////////////////////Getting worldpositon///////////////////////

			vl.d = distx(vl.minDist);
			vl.fragpos = nvec4(convertScreenSpaceToWorldSpace(texcoord.st, vl.d) * 1.0);
			vl.worldposition = vec4(gbufferModelViewInverse * vl.fragpos);

		///////////////////////Converting ScreenSpace to ShadowSpace///////////////////////

			vl.worldposition = (shadowModelView * vl.worldposition);
			vl.worldposition = (shadowProjection * vl.worldposition);

		///////////////////////Rescaling ShadowMaps///////////////////////

			vl.distb = sqrt(vl.worldposition.r*vl.worldposition.r + vl.worldposition.g*vl.worldposition.g);
			vl.distb *= SHADOW_MAP_BIAS;
			vl.distortFactor = 1.0 - SHADOW_MAP_BIAS;
			vl.distortFactor -= vl.distb * - 1.0;

			vl.pos = vl.worldposition.rgb;
			vl.pos.rg /= (sqrt(vl.distortFactor / vl.distortFactor) * (vl.distortFactor));

		///////////////////////Projecting shadowmaps on a linear depth plane///////////////////////

			vl.VolumetricRays += (shadow2D(shadow, vec3(vl.pos.rg, vl.pos.b + vl.pushback.r) * 0.5 + 0.5).z);

			vl.minDist = vl.minDist + vl.steps;
	}

	///////////////////////Returning the program///////////////////////

		vl.VolumetricRays /= vl.weight;
		vl.VolumetricRays *= 0.15;

		return mix(vl.VolumetricRays, clamp(vl.VolumetricRays, 0.0, 0.1), dynamicExposure())/1.5/(1.0+rainStrength*5.0);
}

#else
	float GetVolumetricRays(){

		return 0.0;
	}
#endif

#ifdef DYNAMIC_EXPOSURE
vec3 dynamicExposure(vec3 color) {
	return color.rgb * clamp((-eyeBrightnessSmooth.y+230)/100.0,0.0,1.0)*DYNAMIC_EXPOSURE_VAR;
	int LOD = int(log2(max(viewWidth, viewHeight)));		
}
#endif

//////////////////////////////VOID MAIN//////////////////////////////
//////////////////////////////VOID MAIN//////////////////////////////
//////////////////////////////VOID MAIN//////////////////////////////
//////////////////////////////VOID MAIN//////////////////////////////
//////////////////////////////VOID MAIN//////////////////////////////

void main() {

fragpos = nvec3(gbufferProjectionInverse * nvec4(fragpos * 2.0 - 1.0));

#ifndef DYNAMIC_HANDLIGHT
handlight = 0.0;
#endif

vec2 newtc = texcoord.xy;

// Unpack Material flags //

float land = float(aux.g > 0.04);
float iswater = float(aux.g > 0.04 && aux.g < 0.07);
float translucent = float(aux.g > 0.3 && aux.g < 0.5);
float tallgrass = float(aux.g > 0.42 && aux.g < 0.48);
float hand = float(aux.g > 0.75 && aux.g < 0.85);
float emissive = float(aux.g > 0.58 && aux.g < 0.62);
float shading = 0.0f;
float spec = 0.0;

vec3 nsunlight = normalize(mix(pow(sunlight,vec3(2.2)),vec3(0.25,0.3,0.4),rainStrength));
sky_color = normalize(mix(sky_color,vec3(0.25,0.3,0.4),rainStrength)); //normalize colors in order to don't change luminance

	float fresnel_pow = 5.0;

	vec3 color = texture2D(gcolor, newtc.st).rgb;
	color = pow(color,vec3(2.2))*(.75+tallgrass*0.2)*1.0;

	float NdotL = dot(lightVector,normal);
	float NdotUp = dot(normal,upVec);

	vec4 fragposition = gbufferProjectionInverse * vec4(newtc.s * 2.0f - 1.0f, newtc.t * 2.0f - 1.0f, 2.0f * pixeldepth - 1.0f, 1.0f);
	fragposition /= fragposition.w;

	vec4 fragpositions = gbufferProjectionInverse * vec4(texcoord.s * 2.0f - 1.0f, texcoord.t * 2.0f - 1.0f, 2.0f * pixeldepth - 1.0f, 1.0f);
	fragpositions /= fragpositions.w;

	vec4 worldposition = vec4(0.0);
	vec4 worldpositionraw = vec4(0.0);
	worldposition = gbufferModelViewInverse * fragposition;
	float xzDistanceSquared = worldposition.x * worldposition.x + worldposition.z * worldposition.z;
	float yDistanceSquared  = worldposition.y * worldposition.y;
	worldpositionraw = worldposition;

	float time = float(worldTime);
	float transition_fading = 1.0-(clamp((time-12000.0)/300.0,0.0,1.0)-clamp((time-13500.0)/300.0,0.0,1.0) + clamp((time-22500.0)/300.0,0.0,1.0)-clamp((time-23400.0)/300.0,0.0,1.0));	//fading between sun/moon shadows
	float night = clamp((time-12000.0)/300.0,0.0,1.0)-clamp((time-22800.0)/200.0,0.0,1.0);

	vec3 uPos = vec3(.0);

	if (iswater > 0.9) {

	vec3 posxz = worldposition.xyz+cameraPosition;
	posxz.x += sin(posxz.z+frameTimeCounter)*0.4;
	posxz.z += cos(posxz.x+frameTimeCounter*0.5)*0.4;

	float deltaPos = 0.4;
	float h0 = waterH(posxz);
	float h1 = waterH(posxz + vec3(deltaPos,0.0,0.0));
	float h2 = waterH(posxz + vec3(-deltaPos,0.0,0.0));
	float h3 = waterH(posxz + vec3(0.0,0.0,deltaPos));
	float h4 = waterH(posxz + vec3(0.0,0.0,-deltaPos));

	float xDelta = ((h1-h0)+(h0-h2))/deltaPos;
	float yDelta = ((h3-h0)+(h0-h4))/deltaPos;

	float refMult = 0.0025-dot(normal,normalize(fragposition).xyz)*0.0015;

	vec3 refract = normalize(vec3(xDelta,yDelta,1.0-xDelta*xDelta-yDelta*yDelta));
	vec4 rA = texture2D(gcolor, newtc.st + refract.xy*refMult);
	rA.rgb = pow(rA.rgb,vec3(2.2));
	vec4 rB = texture2D(gcolor, newtc.st);
	rB.rgb = pow(rB.rgb,vec3(2.2));
	float mask = texture2D(gaux1, newtc.st + refract.xy*refMult).g;
	mask =  float(mask > 0.04 && mask < 0.07);
	newtc = (newtc.st + refract.xy*refMult)*mask + texcoord.xy*(1-mask);
	float uDepth = texture2D(depthtex1,newtc.xy).x;
	color.rgb = pow(texture2D(gcolor,newtc.xy).rgb,vec3(2.2));
	uPos  = nvec3(gbufferProjectionInverse * nvec4(vec3(newtc.xy,uDepth) * 2.0 - 1.0));
	}

	if (land > 0.9) {
		float dist = length(fragposition.xyz);
		float distof2 = clamp(1.0-pow(dist/(shadowDistance),2.0),0.0,1.0);
		float shadow_fade = sqrt(clamp(1.0 - xzDistanceSquared / (shadowDistance*shadowDistance), 0.0, 1.0) * clamp(1.0 - yDistanceSquared / (shadowDistance*shadowDistance), 0.0, 1.0));
		float sss_fade = pow(distof2,0.2);

		/*--reprojecting into shadow space --*/

		worldposition = shadowModelView * worldposition;
		float comparedepth = abs(worldposition.z);
		worldposition = shadowProjection * worldposition;
		worldposition /= worldposition.w;
		float distb = sqrt(worldposition.x * worldposition.x + worldposition.y * worldposition.y);
		float distortFactor = (1.0f - SHADOW_MAP_BIAS) + distb * SHADOW_MAP_BIAS;
		worldposition.xy *= 1.0f / distortFactor;
		worldposition = worldposition * 0.5f + 0.5f;

		/*---------------------------------*/

		float step = 3.0/shadowMapResolution*(1.0+rainStrength*5.0);

		float NdotL = dot(normal, lightVector);
		float diffthresh = (pow(distortFactor*1.2,2.0)*(0.25/148.0)*(tan(acos(abs(NdotL)))) + (0.02/148.0))*(1.0+iswater*2.0);
		diffthresh = mix(diffthresh,0.0005,translucent)*(1.+tallgrass*0.1*clamp(tan(acos(abs(NdotL))),0.0,2.));

		if (comparedepth > 0.02 &&	worldposition.s < 0.98 && worldposition.s > 0.02 && worldposition.t < 0.98 && worldposition.t > 0.02 ) {
			if ((NdotL < 0.0 && translucent < 0.1) || (sky_lightmap < 0.01 && eyeBrightness.y < 2)) {
					shading = 0.0;
				}

			else {
			#if SHADOW_FILTER == 0
				step = 2.0/shadowMapResolution*(1.0+rainStrength*5.0);
				float weight;
				float totalweight = 0.0;
				float sigma = 0.25;
				float A = 1.0/sqrt(2.0*3.14159265359*sigma);

				for(int i = 0; i < 60; i++){
					float dist = length(shadow_offsets[i]);
					float weight = A*exp(-(dist*dist)/(2.0*sigma));
					shading += shadow2D(shadow,vec3(worldposition.st + shadow_offsets[i]*step,worldposition.z-diffthresh*(2.0-weight))).x;
					totalweight += 1;
				}

			shading /= totalweight;
			#endif

			step = 0.5/shadowMapResolution*(1.0+rainStrength*5.0);

			#if SHADOW_FILTER == 1
				shading = shadow2D(shadow,vec3(worldposition.st, worldposition.z-diffthresh)).x;
				shading += shadow2D(shadow,vec3(worldposition.st + vec2(step,0), worldposition.z-diffthresh*2)).x;
				shading += shadow2D(shadow,vec3(worldposition.st + vec2(-step,0), worldposition.z-diffthresh*2)).x;
				shading += shadow2D(shadow,vec3(worldposition.st + vec2(0,step), worldposition.z-diffthresh*2)).x;
				shading += shadow2D(shadow,vec3(worldposition.st + vec2(0,-step), worldposition.z-diffthresh*2)).x;
				shading = shading/5.0;
			#endif

			#if SHADOW_FILTER == 2
				shading = shadow2D(shadow,vec3(worldposition.st, worldposition.z-diffthresh)).x;
			#ifdef SHADOW_ACNE_FIX
				shading = shading*15.0;
			#endif
			#endif
			}
		}

		else {
			// Outside shadow map bounds.
			if ((NdotL < 0.0 && translucent < 0.1) || (sky_lightmap < 0.01 && eyeBrightness.y < 2)) {
				shading = 0.0;
			} else {
				// Sample the shadow map at the nearest valid UV (clamped to the SM border)
				// so that blocks just outside the boundary match the shadow value of blocks
				// just inside, eliminating the hard V-shaped seam.
				vec2 clamped_st = clamp(worldposition.st, vec2(0.02), vec2(0.98));
				shading = shadow2D(shadow, vec3(clamped_st, worldposition.z - 0.0001)).x;
				// Fade toward sky_lightmap^2 for blocks progressively further outside the SM
				// so distant untracked blocks eventually return to full (sky-exposed) lighting.
				float outside_uv = max(
					max(0.02 - worldposition.s, worldposition.s - 0.98),
					max(0.02 - worldposition.t, worldposition.t - 0.98)
				);
				shading = mix(shading, sky_lightmap * sky_lightmap, smoothstep(0.0, 0.1, outside_uv));
			}
		}
		#ifdef CAVE_LEAKING_FIX
		if (sky_lightmap < 0.01 && eyeBrightness.y < 0.5) {
					shading = 0.0;
				}
		#endif
		#ifdef WATER_LEAKING_FIX
		if (isEyeInWater == 1) {
					shading = 0.0;
				}
		#endif

		vec3 npos = normalize(fragposition.xyz);

		float diffuse = max(dot(lightVector,normal),0.0);
		diffuse = mix(diffuse,1.0,translucent*0.8);

		float sss = subSurfaceScattering(fragposition.xyz,30.0)*SUNLIGHTAMOUNT;

		float sssSunrise = (SSS_STRENGTH*TimeSunrise);
		float sssDay = (SSS_STRENGTH*TimeNoon)/1.5;
		float sssSunset = (SSS_STRENGTH*TimeSunset)*1.2;
		float sssMidnight = (SSS_STRENGTH*TimeMidnight)/5.0;
		float sssFinal = (sssSunrise + sssDay + sssSunset + sssMidnight);

		sss = (mix(0.0,sss,max(shadow_fade-0.5,0.0)*2.0)*0.5+0.5)*sssFinal;

		float handLight = (handlight*50.5)/pow(1.0+length(fragposition.xyz/1.4),3.0)*sqrt(dot(normalize(fragposition.xyz), -normal)*0.5+0.51);

#ifdef WATER_CAUSTIC
//Generates above water caustics
	color += waterCaustic(fragpos.xyz,color.rgb)*iswater;

//Generates underwater caustics
	if (land > 0.9 && hand < 0.1)
	color += waterCaustic(fragpos.xyz,color.rgb*1.0*(1.0-iswater))*isEyeInWater;
#endif

float ao = 1.0;

vec3 sunlight_sunrise = vec3(SRR, SRG, SRB) * TimeSunrise/5.0;
vec3 sunlight_noon = vec3(NR, NG, NB) * TimeNoon/8.0;
vec3 sunlight_sunset = vec3(SSR, SSG, SSB) * TimeSunset/5.0;
vec3 sunlight_midnight = vec3(MNR, MNG, MNB) * (TimeMidnight);
	
vec3 sunlight_color = sunlight_sunrise + sunlight_noon + sunlight_sunset + (sunlight_midnight);

	//Apply different lightmaps to image
		shading = clamp(shading,0.0,1.0);
		vec3 light_col = mix(pow(sunlight,vec3(2.2)),moonlight,moonVisibility);
		light_col = mix(light_col,vec3(length(light_col))*0.3,rainStrength*0.9);	
		vec3 Sunlight_lightmap = light_col*shading*sunlight_color*3.0*(1.0-rainStrength*0.95)*SUNLIGHTAMOUNT*diffuse*transition_fading ;
		#if UNDERWATER_COLOR == 0
		vec3 Ucolor= normalize(vec3(sky_color));
                #endif
		#if UNDERWATER_COLOR == 1
		vec3 Ucolor= normalize(vec3(0.0,0.7,1.0));
                #endif
		#if UNDERWATER_COLOR == 2
		vec3 Ucolor= normalize(vec3(watercolor));
                #endif
		#if UNDERWATER_COLOR == 3
		vec3 Ucolor= normalize(vec3(0.1,0.23,1.0));
                #endif

		// Underwater position

		vec3 uVec = fragpositions.xyz-uPos;
		float UNdotUP = abs(dot(normalize(uVec),normal));
		float depth = length(uVec)*UNdotUP;
		float sky_absorbance = mix(mix(1.0,exp(-depth/1.5),iswater),1.0,isEyeInWater);

		float visibility = sky_lightmap;
		float bouncefactor = sqrt((NdotUp*0.3+0.61) * pow(1.01-NdotL*NdotL,2.0)+0.5)*0.66;
		float cfBounce = (-NdotL*0.45+0.56);

		vec3 emissive = (1/length(color))*(emissive+handlight*hand)*eyeAdapt*color*3.0;

		vec3 bounceSunlight = 3.2*cfBounce*light_col*visibility*visibility*visibility*SHADOW_DARKNESS * (1-rainStrength*0.9)*transition_fading;

		float tL = (lightS.x*pow(sky_lightmap,2.2) + lightS.y)/5.5;
		float tLMoon = (lightS.z + lightS.w)/3.;

		vec3 skycolor = mix(sky_color, nsunlight,1-exp(-9999.99*tL*(1-rainStrength*0.8)))*tL*sunVisibility*(1-rainStrength*0.8) + tLMoon*moonVisibility*moonlight;

		vec3 sky_light = SHADOW_DARKNESS*skycolor*visibility*bouncefactor*(1+moonVisibility*0.7);

		vec3 torchcolor = vec3(TORCH_COLOR_LIGHTING)*eyeAdapt;

		vec3 Torchlight_lightmap = (torch_lightmap + handLight) * torchcolor ;
		vec3 color_torchlight = Torchlight_lightmap;

        #ifdef RGB_MODE
		color.rgb = vec3(RGB, GGB, BGB);
		#endif

		if (land > 0.9){
                  #ifdef NIGHT_DESATURATION
                  #include "/lib/effect/lighting/nightdesaturation.glsl"
                  #endif
		  }

		color = ((bounceSunlight+sky_light)*ao+ Sunlight_lightmap*ao + color_torchlight*ao +  sss * light_col * shading *(1.0-rainStrength*0.9)*transition_fading + emissive)*color*sky_absorbance;
		if (iswater > 0.9) color = mix(Ucolor*length(ambient_color)*0.008*sky_lightmap,color,exp(-depth/16));

		float gfactor = 1.0;
		spec = Blinn_Phong(fragposition.xyz,lightVector,normal,fresnel_pow,gfactor,pow(sky_lightmap, 5.0)*diffuse) *iswater * (1.0-isEyeInWater)*transition_fading;
	}

float gr = 0.0;
#ifdef GODRAYS
#include "/lib/effect/lighting/godrays.glsl"
#endif
#ifdef CELSHADING
	if (iswater < 0.9) color = celshade(color);
#endif
#ifdef INFO

#endif
#ifdef INFO2

#endif
#ifdef INFO3

#endif
#ifdef DYNAMIC_EXPOSURE
	color.rgb += dynamicExposure(color);
#endif

	color = clamp(pow(color/MAX_COLOR_RANGE,vec3(1.0/2.2)),0.0,1.0);
/* DRAWBUFFERS:31 */
	gl_FragData[0] = vec4(color, spec);
	#ifdef VOLUMETRIC_LIGHT
	gl_FragData[1] = vec4(0,GetVolumetricRays(),1.0,1.0);
	#else
	gl_FragData[1] = vec4(vec3((gr/NUM_SAMPLES)),1.0);
	#endif
}

#endif

///// VERTEX SHADER //////////////////////////////////////////////////////////////////////////////////////////////
#ifdef VSH
varying vec4 texcoord;

varying vec3 lightVector;
varying vec3 sunVec;
varying vec3 moonVec;
varying vec3 upVec;

varying vec4 lightS;


varying vec3 sunlight;
varying vec3 moonlight;
varying vec3 ambient_color;

varying float handItemLight;
varying float eyeAdapt;

varying float SdotU;
varying float MdotU;
varying float sunVisibility;
varying float moonVisibility;

uniform vec3 skyColor;
uniform vec3 sunPosition;
uniform vec3 upPosition;
uniform int worldTime;
uniform int heldItemId;
uniform int heldBlockLightValue;
uniform float rainStrength;
uniform float wetness;
uniform ivec2 eyeBrightnessSmooth;

////////////////////sunlight color////////////////////
////////////////////sunlight color////////////////////
////////////////////sunlight color////////////////////
#include "/lib/color/sunlight.glsl"				

float fx(float x) {
return (2 *(-sin(x)*sin(x)*sin(x) + 3*sin(x) + 3*x)) / 3;

}
float fx2(float x) {
return (-cos(x) * sin(x) + 6*x) / 2;

}
//////////////////////////////VOID MAIN//////////////////////////////
//////////////////////////////VOID MAIN//////////////////////////////
//////////////////////////////VOID MAIN//////////////////////////////
//////////////////////////////VOID MAIN//////////////////////////////
//////////////////////////////VOID MAIN//////////////////////////////

void main() {
	moonlight = ivec3(3,4,8)/255.0*MOONLIGHT_AMOUNT;

	gl_Position = ftransform();
	texcoord = gl_MultiTexCoord0;

	if (worldTime < 12700 || worldTime > 23250) {
		lightVector = normalize(sunPosition);
	}
	else {
		lightVector = normalize(-sunPosition);
	}

	sunVec = normalize(sunPosition);
	moonVec = normalize(-sunPosition);
	upVec = normalize(upPosition);

	SdotU = dot(sunVec,upVec);
	MdotU = dot(moonVec,upVec);
	sunVisibility = pow(clamp(SdotU+0.1,0.0,0.1)/0.1,2.0);
	moonVisibility = pow(clamp(MdotU+0.1,0.0,0.1)/0.1,2.0);


	float hour = mod(worldTime/1000.0+6.0,24);
	//if (hour > 24.0) hour = hour - 24.0;

	ivec4 temp = ToD[int(floor(hour))];
	ivec4 temp2 = ToD[int(floor(hour)) + 1];

	sunlight = mix(vec3(temp.yzw),vec3(temp2.yzw),(hour-float(temp.x))/float(temp2.x-temp.x))/255.0f;


sky_color = pow(sky_color,vec3(2.2));
vec3 nsunlight = normalize(mix(pow(sunlight,vec3(4.2)),vec3(0.25,0.3,0.4),rainStrength));
sky_color = normalize(mix(sky_color,vec3(0.25,0.3,0.4),rainStrength)); //normalize colors in order to don't change luminance
vec3 sVector = normalize(upVec);
const float PI = 3.14159265359;
float cosT = 1.;
float T = acos(cosT);
float absCosT = abs(cosT);
float cosS = SdotU;
float S = acos(cosS);
float cosY = cosS;
float Y = acos(cosY);

lightS.x = (fx(Y+PI/2.0)-fx(Y-PI/2.0))*2.0;
lightS.y = (fx2(T+PI/2.0)-fx2(T-PI/2.0))*1.2;
float tL = (lightS.x+ lightS.y)/6.28;

//moon sky color
float McosS = MdotU;
float MS = acos(McosS);
float McosY = MdotU;
float MY = acos(McosY);

lightS.z = (fx(MY+PI/2.0)-fx(MY-PI/2.0))*3.0;
lightS.w = (fx2(T+PI/2.0)-fx2(T-PI/2.0));
float tLMoon = (lightS.z + lightS.w)/6.28;

ambient_color = mix(sky_color, nsunlight,10-exp(-0.16*tL*(1-rainStrength*0.8)))*tL*sunVisibility*(1-rainStrength*0.8) + tLMoon*moonVisibility+moonlight*2.0;
eyeAdapt = (2.0-min(length(ambient_color),eyeBrightnessSmooth.y/240.0*1.7));


	handItemLight = 0.0;
	if (heldItemId == 50) {
		// torch
		handItemLight = 0.1;
	}

	else if (heldItemId == 76 || heldItemId == 94) {
		// active redstone torch / redstone repeater
		handItemLight = 0.05;
	}

	else if (heldItemId == 89) {
		// lightstone
		handItemLight = 0.2;
	}

	else if (heldItemId == 10 || heldItemId == 11 || heldItemId == 51) {
		// lava / lava / fire
		handItemLight = 0.3;
	}

	else if (heldItemId == 91) {
		// jack-o-lantern
		handItemLight = 0.3;
	}


	else if (heldItemId == 327) {
		handItemLight = 0.2;
	}
}
#endif