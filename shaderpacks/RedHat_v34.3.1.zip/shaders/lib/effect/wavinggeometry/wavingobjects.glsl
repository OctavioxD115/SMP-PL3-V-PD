        #ifdef WAVING_CAMERA
        position.xy += vec2(0.01 * sin(frameTimeCounter * 2.0), 0.01 * cos(frameTimeCounter * 1.0));
        #endif
	#ifdef WAVING_LEAVES
	if ( mc_Entity.x == ENTITY_LEAVES )
			position.xyz += calcMove(worldpos.xyz, 0.0040, 0.0064, 0.0043, 0.0035, 0.0037, 0.0041, vec3(1.0,0.2,1.0), vec3(0.5,0.1,0.5));
	#endif
	#ifdef WAVING_VINES
	if ( mc_Entity.x == ENTITY_VINES )
			position.xyz += calcMove(worldpos.xyz, 0.0040, 0.0064, 0.0043, 0.0035, 0.0037, 0.0041, vec3(1.0,0.2,1.0), vec3(0.5,0.1,0.5));
	#endif
	#ifdef WAVING_METALLIC
	if ( mc_Entity.x == ENTITY_METALLIC )
			position.xyz += calcMove(worldpos.xyz, 0.0020, 0.0044, 0.0023, 0.0015, 0.0017, 0.0021, vec3(1.0,0.2,1.0), vec3(0.5,0.1,0.5))/1.5;
	#endif
	if (istopv > 0.9) {
	#ifdef WAVING_GRASS
	if ( mc_Entity.x == ENTITY_TALLGRASS )
			position.xyz += calcMove(worldpos.xyz, 0.0041, 0.0070, 0.0044, 0.0038, 0.0063, 0.0000, vec3(0.8,0.0,0.8), vec3(0.4,0.0,0.4));
	#endif
	#ifdef WAVING_FLOWERS
	if (mc_Entity.x == ENTITY_FLOWERS )
			position.xyz += calcMove(worldpos.xyz, 0.0041, 0.005, 0.0044, 0.0038, 0.0240, 0.0000, vec3(0.8,0.0,0.8), vec3(0.4,0.0,0.4));
	#endif
	#ifdef WAVING_CROPS
	if ( mc_Entity.x == ENTITY_CROPS )
			position.xyz += calcMove(worldpos.xyz, 0.0041, 0.0070, 0.0044, 0.0038, 0.0240, 0.0000, vec3(0.8,0.0,0.8), vec3(0.4,0.0,0.4));
	#endif
	#ifdef WAVING_MUSHROOM
	if ( mc_Entity.x == ENTITY_MUSHROOM )
	        position.xyz += calcMove(worldpos.xyz, 0.0001, 0.0001, 0.0001, 0.0000, 0.0001, 0.0001, vec3(0.8,0.5,0.4), vec3(0.8,0.3,0.6));
	#endif
	#ifdef WAVING_FIRE
	if ( mc_Entity.x == ENTITY_FIRE)
			position.xyz += calcMove(worldpos.xyz, 0.0105, 0.0096, 0.0087, 0.0063, 0.0097, 0.0156, vec3(1.2,0.4,1.2), vec3(0.8,0.8,0.8));
	#endif
        #ifdef WAVING_NETHER_WART
	if ( mc_Entity.x == ENTITY_NETHER_WART)
			position.xyz += calcMove(worldpos.xyz, 0.0041, 0.0070, 0.0044, 0.0038, 0.0240, 0.0000, vec3(0.8,0.0,0.8), vec3(0.4,0.0,0.4));
	#endif
        #ifdef WAVING_SAPLINGS
	if ( mc_Entity.x == ENTITY_SAPLINGS)
			position.xyz += calcMove(worldpos.xyz, 0.0041, 0.0070, 0.0044, 0.0038, 0.0240, 0.0000, vec3(0.8,0.0,0.8), vec3(0.4,0.0,0.4));
	#endif
	#ifdef WAVING_DEADBUSH
	if ( mc_Entity.x == ENTITY_DEADBUSH )
			position.xyz += calcMove(worldpos.xyz, 0.0040, 0.0064, 0.0043, 0.0035, 0.0037, 0.0041, vec3(1.0,0.2,1.0), vec3(0.5,0.1,0.5));
	#endif
	#ifdef WAVING_UNDERWATER
	if ( mc_Entity.x == ENTITY_UNDERWATER )
			position.xyz += calcMove(worldpos.xyz, 0.0020, 0.0044, 0.0023, 0.0015, 0.0017, 0.0021, vec3(1.0,0.2,1.0), vec3(0.5,0.1,0.5));
	#endif
	}
	#ifdef WAVING_LAVA
	if ( mc_Entity.x == ENTITY_LAVAFLOWING || mc_Entity.x == ENTITY_LAVASTILL ) {
			mat = 0.4;
			position.xyz += calcWaterMove(worldpos.xyz) * 0.25;
			}
	#endif
	#ifdef WAVING_LILYPAD
	if ( mc_Entity.x == ENTITY_LILYPAD ) {
			position.xyz += calcWaterMove(worldpos.xyz);
			mat = 0.4;
			}
	#endif
