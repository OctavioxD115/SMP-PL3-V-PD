	float fgr = clamp(GRAIN_CHECK-(color.r+color.g+color.b),0,1);
	fgr = fgr*fgr;
	vec2 grcoord = vec2(getnoise(newTC.xy/2),getnoise(-newTC.xy/2));
	color += normalize(color)*(getnoise(grcoord)*1.5-0.75)*GRAIN_DENSITY*fgr;