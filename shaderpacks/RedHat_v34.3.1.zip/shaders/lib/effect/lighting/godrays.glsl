        vec4 tpos = vec4(sunPosition,1.0)*gbufferProjection;
	tpos = vec4(tpos.xyz/tpos.w,1.0);
	vec2 pos1 = tpos.xy/tpos.z;
	vec2 lightPos = pos1*0.5+0.5;


		vec2 deltaTextCoord = vec2( newtc.st - lightPos.xy );
		vec2 textCoord = newtc.st;
		deltaTextCoord *= 1.0 /  float(NUM_SAMPLES) * density;
		float avgdecay = 0.0;
		float distx = abs(newtc.x*aspectRatio-lightPos.x*aspectRatio);
		float disty = abs(newtc.y-lightPos.y);
		float fallof = 1.0;
		float noise = getnoise(textCoord);

		for(int i=0; i < NUM_SAMPLES ; i++) {
			textCoord -= deltaTextCoord;

			fallof *= 0.7;
			float sampl1 = step(texture2D(gaux1, textCoord+ deltaTextCoord*noise*grnoise).g,0.0001);
			float sampl2 = step(texture2D(gaux1, textCoord+ deltaTextCoord*noise*grnoise).r,0.0002);
			float sampl3 = step(texture2D(gaux1, textCoord+ deltaTextCoord*noise*grnoise).b,0.0003);
			gr += sampl1*sampl2*sampl3*fallof*GODRAYS_AMOUNT;
		}
