#version 130

// !! DO NOT REMOVE !! !! DO NOT REMOVE !!

// This code is from Chocapic13' shaders
// Read the terms of modification and sharing before changing something below please !

// !! DO NOT REMOVE !! !! DO NOT REMOVE !!

//------------------------------------
//RedHat - Based on Chocapic13' and CYBOX
//
//If you have questions, suggestions or bugs you want to report, please contact me on Discord
//
//
//Before editing, please read the LICENSE
//Thanks
//------------------------------------

#include "/lib/defines/composite.h"
#define VSH
#include "/program/composite.glsl"

