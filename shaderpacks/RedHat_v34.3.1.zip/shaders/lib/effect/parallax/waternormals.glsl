	#if WATER_NORMALS == 0
	float deltaPos = 0.4;
	float h0 = waterH(posxz);
	float h1 = waterH(posxz + vec3(deltaPos,0.0,0.0));
	float h2 = waterH(posxz + vec3(-deltaPos,0.0,0.0));
	float h3 = waterH(posxz + vec3(0.0,0.0,deltaPos));
	float h4 = waterH(posxz + vec3(0.0,0.0,-deltaPos));

	float dX = (h1-h0)-(h0-h2)/deltaPos*1.0;
	float dY = (h3-h0)-(h0-h4)/deltaPos/12.0;
        #elif WATER_NORMALS == 1
	float deltaPos = 0.4;
	float h0 = waterH(posxz);

	float dX = (h0)/deltaPos;
	float dY = (h0)/deltaPos+15.0;
        #endif

	vec3 newnormal = normalize(vec3(dX,dY,1.0-dX*dX-dY*dY));
	newnormal = newnormal + (dX*dY) / (sin(dX) + cos(dY)+frameTimeCounter);	