		  color.r = color.r + ((color.g + color.b)/2.0)*(DESATURATION_STRENGTH)*TimeMidnight;
		  color.g = color.g + ((color.r + color.b)/2.0)*(DESATURATION_STRENGTH)*TimeMidnight;
		  color.b = color.b + ((color.r + color.g)/2.0)*(DESATURATION_STRENGTH)*TimeMidnight;